import Link from "next/link";

export default function About() {
  return (
    <main style={{ fontFamily: "sans-serif", textAlign: "center", padding: "50px" }}>
      <h1>Tentang JEC Tech</h1>
      <p>
        JEC Tech adalah penyedia layanan pembuatan website, toko online, dan layanan komputer
        dengan tenaga profesional dan hasil yang memuaskan.
      </p>
      <Link href="/">← Kembali ke Beranda</Link>
    </main>
  );
}
