import Link from "next/link";

export default function Home() {
  return (
    <main style={{ fontFamily: "sans-serif", textAlign: "center", padding: "50px" }}>
      <h1>Selamat Datang di <span style={{ color: "#0070f3" }}>JEC Tech</span></h1>
      <p>Jasa Pembuatan Website & Penjualan Komputer</p>
      <p>Kami membantu bisnis Anda tampil profesional di dunia digital.</p>

      <nav style={{ marginTop: "30px" }}>
        <Link href="/about">Tentang Kami</Link> |{" "}
        <Link href="/contact">Kontak</Link>
      </nav>
    </main>
  );
}
