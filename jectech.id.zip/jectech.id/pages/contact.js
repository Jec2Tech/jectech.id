import Link from "next/link";

export default function Contact() {
  return (
    <main style={{ fontFamily: "sans-serif", textAlign: "center", padding: "50px" }}>
      <h1>Kontak Kami</h1>
      <p>Hubungi kami melalui:</p>
      <p>📞 0813-1532-4060</p>
      <p>📧 info@jectech.id</p>
      <Link href="/">← Kembali ke Beranda</Link>
    </main>
  );
}
